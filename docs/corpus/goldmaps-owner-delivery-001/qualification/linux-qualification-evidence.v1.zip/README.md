# Linux qualification evidence checkpoint

This is an evidence archive. It is NOT the playable Windows evaluator ZIP.

It preserves the interrupted concurrent campaign's original SIGKILL logs and
annotations, the completed serial Linux campaign (53 aliases / 44 unique
Setups: 42 positive passes and 2 verified original policy refusals), and the
actual browser/native editing product test (26/26 checks). All receipt and
log bytes are original. The early empty-search gallery defect and successful
post-fix product run remain distinguishable.

The contemporary engine is 00cdb02f103265b6dc5224c68283e9a0c8cb449f with exact
Godot 4.7 stable. The separate frozen scientific baseline and verdicts are not
replaced or newly reproduced. This archive establishes Linux headless scope,
not Windows launch, displayed rendering, physical GPU quality, full routes,
or owner preference. Original #155/#183 native refusals remain refusals.

Product-synthetic-fixtures contains clearly labelled Pending/Unclassified QA
review/export files and deliberately painted named copies. These are test
outputs, not owner data, accepted labels, recovered originals or corpus additions.

ARCHIVE-MANIFEST.v1.json records every evidence file's exact byte count and
SHA-256. ZIP member order, timestamps and mode bits are fixed for deterministic
repacking; use the original bytes unchanged. No source/runtime executable is
inside this archive. The actual Windows evaluator is a separately qualified
and separately hashed deliverable.
